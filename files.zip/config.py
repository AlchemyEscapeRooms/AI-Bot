"""
Configuration loader for Alchemy Trading Bot
Reads from .env file in project root
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file from project root
env_path = Path(__file__).parent / '.env'
load_dotenv(env_path)

class Config:
    """Configuration manager that reads from environment variables."""
    
    def __init__(self):
        # Load all Alpaca settings
        self.alpaca_api_key = os.getenv('ALPACA_API_KEY', '')
        self.alpaca_api_secret = os.getenv('ALPACA_API_SECRET', '')
        self.alpaca_base_url = os.getenv('ALPACA_BASE_URL', 'https://paper-api.alpaca.markets')
        
        # Trading settings
        self.paper_trading = os.getenv('PAPER_TRADING', 'true').lower() == 'true'
        
    def get(self, key, default=None):
        """Get config value by dot-notation key."""
        key_map = {
            'alpaca.api_key': self.alpaca_api_key,
            'alpaca.api_secret': self.alpaca_api_secret,
            'alpaca.base_url': self.alpaca_base_url,
            'paper_trading': self.paper_trading,
        }
        return key_map.get(key, default)

# Global config instance
config = Config()

# Quick validation
if __name__ == '__main__':
    print("Config loaded from .env")
    print(f"  API Key: {'*' * 8}{config.alpaca_api_key[-4:] if config.alpaca_api_key else 'NOT SET'}")
    print(f"  Base URL: {config.alpaca_base_url}")
    print(f"  Paper Trading: {config.paper_trading}")
